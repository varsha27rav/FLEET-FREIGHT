package com.cts.client;

import com.cts.dto.VehicleDTO;
import org.springframework.stereotype.Component;

@Component
public class VehicleClientFallback implements VehicleClient {

    @Override
    public VehicleDTO getVehicleById(Long id) {
        VehicleDTO fallback = new VehicleDTO();
        fallback.setVehicleId(id);
        fallback.setStatus("SERVICE_UNAVAILABLE");
        return fallback;
    }
}