package com.cts.service;

import com.cts.dao.RouteRepository;
import com.cts.entity.Route;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RouteService {

    private final RouteRepository routeRepository;

    public RouteService(RouteRepository routeRepository) {
        this.routeRepository = routeRepository;
    }

    public Route create(Route route) {
        if (route.getStatus() == null) {
            route.setStatus(Route.RouteStatus.ACTIVE);
        }
        return routeRepository.save(route);
    }

    public List<Route> getAll() {
        return routeRepository.findAll();
    }

    public Route getById(Long id) {
        return routeRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Route not found: " + id));
    }

    public Route updateStatus(Long id, Route.RouteStatus status) {
        Route route = getById(id);
        route.setStatus(status);
        return routeRepository.save(route);
    }

    public void delete(Long id) {
        if (!routeRepository.existsById(id)) {
            throw new RuntimeException("Route not found: " + id);
        }
        routeRepository.deleteById(id);
    }
}
