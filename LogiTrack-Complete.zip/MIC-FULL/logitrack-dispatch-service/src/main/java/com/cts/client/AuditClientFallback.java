package com.cts.client;

import com.cts.dto.AuditLogRequest;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * Silent fallback: if Auth Service is down, log to console and return OK
 * so the calling business operation can still complete.
 */
@Component
public class AuditClientFallback implements AuditClient {
    @Override
    public Map<String, String> writeAudit(AuditLogRequest request) {
        System.err.println("[AUDIT FALLBACK] Could not write to central audit_logs: " +
                "userId=" + request.getUserId() +
                ", action=" + request.getAction() +
                ", details=" + request.getDetails());
        return Map.of("status", "fallback");
    }
}
