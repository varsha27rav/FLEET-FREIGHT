package com.cts.service;

import com.cts.dao.RouteScheduleRepository;
import com.cts.entity.RouteSchedule;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class ScheduleService {

    private final RouteScheduleRepository routeScheduleRepository;

    public ScheduleService(RouteScheduleRepository routeScheduleRepository) {
        this.routeScheduleRepository = routeScheduleRepository;
    }

    public RouteSchedule create(RouteSchedule schedule) {
        if (schedule.getStatus() == null) {
            schedule.setStatus(RouteSchedule.ScheduleStatus.SCHEDULED);
        }
        if (schedule.getDepartureAt() != null && schedule.getArrivalAt() != null
                && !schedule.getArrivalAt().isAfter(schedule.getDepartureAt())) {
            throw new RuntimeException("arrivalAt must be after departureAt");
        }
        if (schedule.getVehicleId() != null
                && schedule.getDepartureAt() != null
                && schedule.getArrivalAt() != null
                && !isVehicleAvailable(schedule.getVehicleId(),
                                       schedule.getDepartureAt(),
                                       schedule.getArrivalAt())) {
            throw new RuntimeException("Vehicle " + schedule.getVehicleId()
                    + " already has an overlapping schedule.");
        }
        return routeScheduleRepository.save(schedule);
    }

    public List<RouteSchedule> getAll() {
        return routeScheduleRepository.findAll();
    }

    public RouteSchedule getById(Long id) {
        return routeScheduleRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Schedule not found: " + id));
    }

    public List<RouteSchedule> getByVehicle(Long vehicleId) {
        return routeScheduleRepository.findByVehicleId(vehicleId);
    }

    public List<RouteSchedule> getByDriverId(Long driverId) {
        return routeScheduleRepository.findScheduledRidesByDriverId(driverId);
    }

    public RouteSchedule updateStatus(Long id, String status) {
        RouteSchedule schedule = getById(id);
        schedule.setStatus(RouteSchedule.ScheduleStatus.valueOf(status));
        return routeScheduleRepository.save(schedule);
    }

    public void delete(Long id) {
        if (!routeScheduleRepository.existsById(id)) {
            throw new RuntimeException("Schedule not found: " + id);
        }
        routeScheduleRepository.deleteById(id);
    }


    public boolean isVehicleAvailable(Long vehicleId, LocalDateTime start, LocalDateTime end) {
        return routeScheduleRepository.countOverlappingSchedules(
                vehicleId, start, end,
                java.util.List.of(
                        RouteSchedule.ScheduleStatus.SCHEDULED,
                        RouteSchedule.ScheduleStatus.IN_TRANSIT)) == 0;
    }

}
