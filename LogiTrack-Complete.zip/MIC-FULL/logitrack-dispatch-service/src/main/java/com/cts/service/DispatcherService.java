package com.cts.service;

import com.cts.client.AuditClient;
import com.cts.client.ShipmentClient;
import com.cts.client.VehicleClient;
import com.cts.dao.DriverAssignmentRepository;
import com.cts.dao.RouteScheduleRepository;
import com.cts.dto.AuditLogRequest;
import com.cts.dto.DispatchRequest;
import com.cts.dto.ShipmentDTO;
import com.cts.dto.VehicleDTO;
import com.cts.entity.DriverAssignment;
import com.cts.entity.RouteSchedule;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
public class DispatcherService {

    private final RouteScheduleRepository routeScheduleRepository;
    private final DriverAssignmentRepository driverAssignmentRepository;
    private final AuditClient auditClient;
    private final ShipmentClient shipmentClient;
    private final VehicleClient vehicleClient;

    public DispatcherService(RouteScheduleRepository routeScheduleRepository,
                             DriverAssignmentRepository driverAssignmentRepository,
                             AuditClient auditClient,
                             ShipmentClient shipmentClient,
                             VehicleClient vehicleClient) {
        this.routeScheduleRepository = routeScheduleRepository;
        this.driverAssignmentRepository = driverAssignmentRepository;
        this.auditClient = auditClient;
        this.shipmentClient = shipmentClient;
        this.vehicleClient = vehicleClient;
    }

    private void audit(Long userId, String action, String details) {
        try {
            auditClient.writeAudit(new AuditLogRequest(userId, action, details));
        } catch (Exception ignored) {}
    }

    @Transactional
    public Map<String, Object> dispatchShipment(DispatchRequest request, Long dispatcherId) {
        if (request.getShipmentId() == null) throw new IllegalArgumentException("shipmentId is required.");
        if (request.getVehicleId() == null) throw new IllegalArgumentException("vehicleId is required.");
        if (request.getRouteId() == null) throw new IllegalArgumentException("routeId is required.");
        if (request.getDriverId() == null) throw new IllegalArgumentException("driverId is required.");

        VehicleDTO vehicle = vehicleClient.getVehicleById(request.getVehicleId());
        if (vehicle == null || vehicle.getVehicleId() == null) {
            throw new RuntimeException("Vehicle " + request.getVehicleId() + " not found.");
        }
        if (!"AVAILABLE".equals(vehicle.getStatus())) {
            throw new RuntimeException("Vehicle " + vehicle.getRegNumber() +
                    " is currently " + vehicle.getStatus() + " and cannot be assigned.");
        }

        Optional<RouteSchedule> existing = routeScheduleRepository.findByShipmentId(request.getShipmentId());
        if (existing.isPresent()) {
            throw new RuntimeException("Shipment #" + request.getShipmentId() + " is already scheduled.");
        }

        ShipmentDTO shipment = shipmentClient.getShipmentById(request.getShipmentId());
        if (shipment == null || "SERVICE_UNAVAILABLE".equals(shipment.getStatus())) {
            throw new RuntimeException("Shipment service is unavailable, cannot dispatch shipment "
                    + request.getShipmentId());
        }

        shipmentClient.updateShipmentStatus(request.getShipmentId(), "ACCEPTED");

        RouteSchedule schedule = new RouteSchedule();
        schedule.setShipmentId(request.getShipmentId());
        schedule.setVehicleId(request.getVehicleId());
        schedule.setRouteId(request.getRouteId());
        schedule.setDepartureAt(request.getDepartureAt());
        schedule.setArrivalAt(request.getArrivalAt());
        schedule.setDispatcherId(dispatcherId);
        schedule.setStatus(RouteSchedule.ScheduleStatus.SCHEDULED);
        RouteSchedule savedSchedule = routeScheduleRepository.save(schedule);

        DriverAssignment assignment = new DriverAssignment();
        assignment.setDriverId(request.getDriverId());
        assignment.setVehicleId(request.getVehicleId());
        assignment.setRouteId(request.getRouteId());
        assignment.setAssignedBy(dispatcherId);
        assignment.setAssignedAt(LocalDateTime.now());
        assignment.setStatus("ACTIVE");
        DriverAssignment savedAssignment = driverAssignmentRepository.save(assignment);

        audit(dispatcherId, "DISPATCH_CREATED",
                "Shipment " + shipment.getShipmentId() + " assigned to vehicle " + vehicle.getRegNumber()
                        + " (driver #" + request.getDriverId() + ")");

        Map<String, Object> response = new LinkedHashMap<>();
        response.put("message", "Shipment dispatched successfully.");
        response.put("scheduleId", savedSchedule.getScheduleId());
        response.put("assignId", savedAssignment.getAssignId());
        response.put("driverId", savedAssignment.getDriverId());
        response.put("vehicleId", savedAssignment.getVehicleId());
        response.put("routeId", savedAssignment.getRouteId());
        response.put("shipmentId", savedSchedule.getShipmentId());
        response.put("departureAt", savedSchedule.getDepartureAt());
        response.put("arrivalAt", savedSchedule.getArrivalAt());
        response.put("scheduleStatus", savedSchedule.getStatus());
        response.put("assignmentStatus", savedAssignment.getStatus());
        response.put("dispatcherId", dispatcherId);
        return response;
    }

    @Transactional
    public void cancelFullDispatch(Long shipmentId, Long dispatcherId) {
        shipmentClient.updateShipmentStatus(shipmentId, "CANCELLED");

        Optional<RouteSchedule> scheduleOpt = routeScheduleRepository.findByShipmentId(shipmentId);
        scheduleOpt.ifPresent(s -> {
            s.setStatus(RouteSchedule.ScheduleStatus.CANCELLED);
            routeScheduleRepository.save(s);
        });

        scheduleOpt.ifPresent(s -> {
            List<DriverAssignment> matching = driverAssignmentRepository
                    .findByVehicleIdAndRouteIdAndStatus(s.getVehicleId(), s.getRouteId(), "ACTIVE");
            for (DriverAssignment a : matching) {
                a.setStatus("CANCELLED");
                driverAssignmentRepository.save(a);
            }
        });

        audit(dispatcherId, "DISPATCH_CANCELLED",
                "Full cancellation of Shipment #" + shipmentId);
    }
}
