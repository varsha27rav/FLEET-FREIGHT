package com.cts.controller;

import com.cts.client.AuditClient;
import com.cts.client.ShipmentClient;
import com.cts.dao.DriverAssignmentRepository;
import com.cts.dao.RouteScheduleRepository;
import com.cts.dto.AuditLogRequest;
import com.cts.dto.DispatchRequest;
import com.cts.dto.ShipmentDTO;
import com.cts.entity.DriverAssignment;
import com.cts.security.AuthUser;
import com.cts.service.DispatcherService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/dispatcher")
@PreAuthorize("hasAnyRole('ADMIN', 'DISPATCHER')")
public class DispatcherController {

    private final DispatcherService dispatcherService;
    private final ShipmentClient shipmentClient;
    private final AuditClient auditClient;
    private final DriverAssignmentRepository driverAssignmentRepository;
    private final RouteScheduleRepository routeScheduleRepository;

    public DispatcherController(DispatcherService dispatcherService,
                                ShipmentClient shipmentClient,
                                AuditClient auditClient,
                                DriverAssignmentRepository driverAssignmentRepository,
                                RouteScheduleRepository routeScheduleRepository) {
        this.dispatcherService = dispatcherService;
        this.shipmentClient = shipmentClient;
        this.auditClient = auditClient;
        this.driverAssignmentRepository = driverAssignmentRepository;
        this.routeScheduleRepository = routeScheduleRepository;
    }

    private void audit(Long userId, String action, String details) {
        try {
            auditClient.writeAudit(new AuditLogRequest(userId, action, details));
        } catch (Exception ignored) {}
    }

    @GetMapping("/shipments")
    public ResponseEntity<List<ShipmentDTO>> getShipments() {
        return ResponseEntity.ok(shipmentClient.getAllShipments());
    }

    @PutMapping("/shipments/{id}/cancel")
    public ResponseEntity<?> cancelShipment(@PathVariable Long id, Authentication auth) {
        shipmentClient.updateShipmentStatus(id, "CANCELLED");
        AuthUser dispatcher = (AuthUser) auth.getPrincipal();
        audit(dispatcher.getUserId(), "SHIPMENT_CANCELLED",
                "Dispatcher cancelled shipment ID: " + id);
        return ResponseEntity.ok(Map.of("message", "Shipment cancelled successfully."));
    }

    @PostMapping("/dispatch")
    public ResponseEntity<?> processDispatch(Authentication auth,
                                             @RequestBody DispatchRequest request) {
        AuthUser dispatcher = (AuthUser) auth.getPrincipal();
        try {
            Map<String, Object> result = dispatcherService.dispatchShipment(request, dispatcher.getUserId());
            return ResponseEntity.ok(result);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        } catch (RuntimeException e) {
            return ResponseEntity.unprocessableEntity().body(Map.of("error", e.getMessage()));
        }
    }

    @PutMapping("/shipments/{id}/cancel-dispatch")
    public ResponseEntity<?> cancelDispatch(@PathVariable Long id, Authentication auth) {
        AuthUser dispatcher = (AuthUser) auth.getPrincipal();
        try {
            dispatcherService.cancelFullDispatch(id, dispatcher.getUserId());
            return ResponseEntity.ok(Map.of("message", "Dispatch cancelled successfully."));
        } catch (RuntimeException e) {
            return ResponseEntity.unprocessableEntity().body(Map.of("error", e.getMessage()));
        }
    }

    @GetMapping("/assignments")
    public ResponseEntity<List<DriverAssignment>> getAllAssignments() {
        return ResponseEntity.ok(driverAssignmentRepository.findAll());
    }

    @GetMapping("/assignments/driver/{driverId}")
    public ResponseEntity<List<DriverAssignment>> getAssignmentsByDriver(@PathVariable Long driverId) {
        return ResponseEntity.ok(driverAssignmentRepository.findByDriverId(driverId));
    }

    @GetMapping("/schedules/shipment/{shipmentId}")
    public ResponseEntity<?> getScheduleByShipment(@PathVariable Long shipmentId) {
        return routeScheduleRepository.findByShipmentId(shipmentId)
                .<ResponseEntity<?>>map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(404)
                        .body(Map.of("error", "No schedule for shipment " + shipmentId)));
    }
}
