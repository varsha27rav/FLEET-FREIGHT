package com.cts.dao;

import com.cts.entity.DriverAssignment;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DriverAssignmentRepository extends JpaRepository<DriverAssignment, Long> {
    Optional<DriverAssignment> findByDriverIdAndVehicleIdAndStatus(Long driverId, Long vehicleId, String status);

    List<DriverAssignment> findByVehicleIdAndRouteIdAndStatus(Long vehicleId, Long routeId, String status);

    List<DriverAssignment> findByDriverId(Long driverId);

    List<DriverAssignment> findByAssignedBy(Long assignedBy);
}
