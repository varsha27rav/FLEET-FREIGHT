package com.cts.controller;

import com.cts.entity.Route;
import com.cts.service.RouteService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/dispatcher/routes")
@PreAuthorize("hasAnyRole('ADMIN','DISPATCHER')")
public class RouteController {

    private final RouteService routeService;

    public RouteController(RouteService routeService) {
        this.routeService = routeService;
    }

    @PostMapping("/create")
    public ResponseEntity<Route> create(@Valid @RequestBody Route route) {
        return ResponseEntity.ok(routeService.create(route));
    }

    @GetMapping("/all-routes")
    public ResponseEntity<List<Route>> getAll() {
        return ResponseEntity.ok(routeService.getAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Route> getById(@PathVariable Long id) {
        return ResponseEntity.ok(routeService.getById(id));
    }

    @PatchMapping("/{id}/status")
    public ResponseEntity<Route> updateStatus(@PathVariable Long id,
                                              @RequestParam Route.RouteStatus status) {
        return ResponseEntity.ok(routeService.updateStatus(id, status));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Map<String, String>> delete(@PathVariable Long id) {
        routeService.delete(id);
        return ResponseEntity.ok(Map.of("message", "Route " + id + " deleted."));
    }
}
