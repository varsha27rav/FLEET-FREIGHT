package com.cts.controller;

import com.cts.client.VehicleClient;
import com.cts.dto.VehicleDTO;
import com.cts.entity.RouteSchedule;
import com.cts.service.ScheduleService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/dispatcher/schedules")
@PreAuthorize("hasAnyRole('ADMIN','DISPATCHER')")
public class ScheduleController {

    private final ScheduleService scheduleService;
    private final VehicleClient vehicleClient;

    public ScheduleController(ScheduleService scheduleService, VehicleClient vehicleClient) {
        this.scheduleService = scheduleService;
        this.vehicleClient = vehicleClient;
    }

    @PostMapping("/create")
    public ResponseEntity<RouteSchedule> create(@Valid @RequestBody RouteSchedule schedule) {
        return ResponseEntity.ok(scheduleService.create(schedule));
    }

    @GetMapping("/route-schedule-all")
    public ResponseEntity<List<RouteSchedule>> getAll() {
        return ResponseEntity.ok(scheduleService.getAll());
    }

    @GetMapping("/{scheduleId}")
    @PreAuthorize("hasAnyRole('ADMIN','DISPATCHER','DRIVER')")
    public ResponseEntity<RouteSchedule> getById(@PathVariable Long scheduleId) {
        return ResponseEntity.ok(scheduleService.getById(scheduleId));
    }

    @GetMapping("/vehicle/{vehicleId}")
    public ResponseEntity<List<RouteSchedule>> getByVehicle(@PathVariable Long vehicleId) {
        return ResponseEntity.ok(scheduleService.getByVehicle(vehicleId));
    }

    @GetMapping("/driver/{driverId}")
    @PreAuthorize("hasAnyRole('ADMIN','DISPATCHER','DRIVER')")
    public ResponseEntity<List<RouteSchedule>> getSchedulesByDriverId(@PathVariable Long driverId) {
        return ResponseEntity.ok(scheduleService.getByDriverId(driverId));
    }

    @PutMapping("/{scheduleId}/status")
    @PreAuthorize("hasAnyRole('ADMIN','DISPATCHER','DRIVER')")
    public ResponseEntity<Map<String, String>> updateScheduleStatus(
            @PathVariable Long scheduleId,
            @RequestBody String status) {
        scheduleService.updateStatus(scheduleId, status);
        return ResponseEntity.ok(Map.of("message", "Schedule " + scheduleId + " status updated to " + status));
    }

    @DeleteMapping("/{scheduleId}")
    public ResponseEntity<Map<String, String>> delete(@PathVariable Long scheduleId) {
        scheduleService.delete(scheduleId);
        return ResponseEntity.ok(Map.of("message", "Schedule " + scheduleId + " deleted."));
    }

    @PostMapping("/check-availability")
    public ResponseEntity<Map<String, Object>> checkAvailability(
            @RequestParam Long vehicleId,
            @RequestParam String start,
            @RequestParam String end) {
        VehicleDTO vehicle = vehicleClient.getVehicleById(vehicleId);
        if (vehicle == null || vehicle.getVehicleId() == null
                || "SERVICE_UNAVAILABLE".equals(vehicle.getStatus())) {
            Map<String, Object> body = new LinkedHashMap<>();
            body.put("available", false);
            body.put("message", "Vehicle not found with id " + vehicleId);
            return ResponseEntity.status(404).body(body);
        }
        if ("IN_MAINTENANCE".equals(vehicle.getStatus())) {
            Map<String, Object> body = new LinkedHashMap<>();
            body.put("available", false);
            body.put("message", "Vehicle is in maintenance");
            return ResponseEntity.ok(body);
        }
        boolean available = scheduleService.isVehicleAvailable(
                vehicleId,
                LocalDateTime.parse(start),
                LocalDateTime.parse(end));
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("available", available);
        body.put("message", available
                ? "Vehicle is available"
                : "Vehicle has an overlapping schedule");
        return ResponseEntity.ok(body);
    }
}
