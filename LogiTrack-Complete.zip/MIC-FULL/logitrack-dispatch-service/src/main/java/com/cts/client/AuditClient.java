package com.cts.client;

import com.cts.dto.AuditLogRequest;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.Map;

/**
 * AuditClient
 * ------------
 * Feign client used by this microservice to write audit events into the
 * central audit_logs table that lives in the Auth Service database.
 * Falls back silently if Auth Service is unreachable so business operations
 * are never blocked by audit failures.
 */
@FeignClient(name = "logitrack-auth-service", path = "/api/admin",
             fallback = AuditClientFallback.class)
public interface AuditClient {

    @PostMapping("/internal/audit-log")
    Map<String, String> writeAudit(@RequestBody AuditLogRequest request);
}
