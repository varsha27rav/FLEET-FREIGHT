package com.cts.dao;

import com.cts.entity.RouteSchedule;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface RouteScheduleRepository extends JpaRepository<RouteSchedule, Long> {

    Optional<RouteSchedule> findByVehicleIdAndRouteIdAndStatus(Long vehicleId, Long routeId, RouteSchedule.ScheduleStatus status);

    Optional<RouteSchedule> findByShipmentId(Long shipmentId);

    List<RouteSchedule> findByVehicleId(Long vehicleId);

    @Query("SELECT COUNT(rs) FROM RouteSchedule rs " +
            "WHERE rs.vehicleId = :vehicleId " +
            "AND rs.status IN :statuses " +
            "AND rs.departureAt < :end AND rs.arrivalAt > :start")
    long countOverlappingSchedules(@Param("vehicleId") Long vehicleId,
                                   @Param("start") LocalDateTime start,
                                   @Param("end") LocalDateTime end,
                                   @Param("statuses") Collection<RouteSchedule.ScheduleStatus> statuses);

    @Query("SELECT rs FROM RouteSchedule rs JOIN DriverAssignment da ON rs.vehicleId = da.vehicleId " +
            "WHERE da.driverId = :driverId AND da.status = 'ACTIVE' " +
            "AND (rs.status = 'SCHEDULED' OR rs.status = 'IN_TRANSIT')")
    List<RouteSchedule> findScheduledRidesByDriverId(@Param("driverId") Long driverId);
}
