# LogiTrack — Complete Project (Backend + Frontend)

This is the LogiTrack project with **`logitrack-common` removed** and **audit logs centralized**
into the Auth Service's database, with all services writing audits via Feign.

## What's Inside
- `logitrack-eureka-server` — service registry (port 8761)
- `logitrack-api-gateway` — single entry point (port 9090)
- `logitrack-auth-service` — auth + central audit log store (port 8081)
- `logitrack-shipment-service` (8082)
- `logitrack-fleet-service` (8083)
- `logitrack-dispatch-service` (8084)
- `logitrack-driver-service` (8085)
- `logitrack-frontend` — Angular 17 UI (unchanged, works as-is)

## Backend Architecture Changes

### Common Module Removed
Each service now contains its own copies of:
- `com.cts.security.JwtTokenProvider`
- `com.cts.security.JwtAuthenticationFilter`
- `com.cts.security.AuthUser`
- `com.cts.constants.Role`
- `com.cts.dto.ApiResponse`
- `com.cts.exception.GlobalExceptionHandler`

### Centralized Audit Logs
- `audit_logs` table lives ONLY in the Auth Service database.
- Auth Service exposes `POST /api/admin/internal/audit-log` (authenticated only).
- Every other service has a Feign `AuditClient` that writes to this endpoint.
- If Auth Service is briefly down, `AuditClientFallback` logs to console and
  business operations continue (audit failures never block real work).

### Audited Events
| Service | Events |
|---------|--------|
| Auth | LOGIN_SUCCESS, LOGIN_FAILURE, LOGOUT, REGISTRATION_REQUEST, REGISTRATION_AUTO_APPROVED, REGISTRATION_APPROVED, REGISTRATION_REJECTED, ROLE_UPDATE, REACTIVATION, DEACTIVATION, PASSWORD_RESET, USERNAME_RECOVERY |
| Shipment | SHIPMENT_CREATED, SHIPMENT_STATUS_UPDATED, DELIVERY_OTP_VERIFIED, DELIVERY_OTP_FAILED, DELIVERY_OTP_REGENERATED |
| Fleet | VEHICLE_CREATED, VEHICLE_UPDATED, VEHICLE_DELETED, INSPECTION_RECORDED, MAINTENANCE_CREATED, MAINTENANCE_STATUS_UPDATED |
| Dispatch | DISPATCH_CREATED, DISPATCH_CANCELLED, SHIPMENT_CANCELLED |
| Driver | TRIP_STARTED, DELIVERY_COMPLETED, DELIVERY_OTP_FAILED |

## Frontend
**The Angular frontend is UNCHANGED.** All backend endpoints, JSON shapes, and JWT format
remained identical, so no UI code changes were needed.

**Bonus:** The existing Audit Logs page (`/admin/audit-logs`) will now automatically display
events from ALL services (shipments, fleet, dispatch, driver) — not just auth — because they
share the same table and the same shape (auditId, userId, action, details, timestamp).

## Configuration Required (every backend service)
```properties
app.jwtSecret=LogiTrackSecureManagementSystemKey2026_Project
app.jwtExpirationMs=86400000
```
MUST be identical across all services.

## Startup Order
1. MySQL on `localhost:3306`
2. Eureka Server (`mvn spring-boot:run`)
3. **Auth Service** (must be up first so audit endpoint is reachable)
4. Shipment, Fleet, Dispatch, Driver — any order
5. API Gateway
6. Frontend: `cd logitrack-frontend && npm install && npm start`

## Default Admin
- Email: `admin@logitrack.com`
- Password: `Admin@123`

## Test the End-to-End Audit Flow
1. Login as admin → get JWT
2. Create a shipment as a customer
3. Open `/admin/audit-logs` in the UI (or `GET /api/admin/audit-logs`)
4. You should see entries like `SHIPMENT_CREATED`, `LOGIN_SUCCESS`, etc. — all in one list.
