package com.cts.controller;

import com.cts.dao.UserRepository;
import com.cts.dto.PhoneOtpRequest;
import com.cts.dto.UsernameRecoveryRequest;
import com.cts.service.AuthService;
import com.cts.service.EmailService;
import com.cts.service.SmsService;
import com.cts.dto.LoginRequest;
import com.cts.dto.RegisterRequest;


import com.cts.service.OtpService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
    private final AuthService authService;
    private final EmailService emailService;
    private final SmsService smsService;
    private final UserRepository userRepository;
    private final OtpService otpService;

    public AuthController(AuthService authService, EmailService emailService, SmsService smsService,  UserRepository userRepository,
                          OtpService otpService) {
        this.authService = authService;
        this.emailService = emailService;
        this.smsService = smsService;
        this.userRepository = userRepository;
        this.otpService = otpService;
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody RegisterRequest data) {
        // Pass the DTO instead of a Map
        return ResponseEntity.ok(Map.of("message", authService.registerUser(data)));
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest data) {
        // Use the DTO getters
        String token = authService.login(data.getEmail(), data.getPassword());
        return ResponseEntity.ok(Map.of("token", token));
    }

    @PostMapping("/forgot-password/reset")
    public ResponseEntity<?> resetPassword(@RequestBody Map<String, String> data) {
        return ResponseEntity.ok(Map.of("message",
                authService.resetPassword(data.get("email"), data.get("otpCode"), data.get("newPassword"))));
    }



    @PostMapping("/request-by-phone")
    public ResponseEntity<?> requestOtpByPhone(@RequestBody PhoneOtpRequest request) {
        String phone = request.getPhoneNumber();
        if (phone == null || phone.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("message", "Phone number is required."));
        }
        if (userRepository.findByPhoneNumber(phone).isEmpty()) {
            return ResponseEntity.status(404).body(Map.of("message",
                    "No account is registered with this phone number."));
        }
        String code = otpService.generateAndSaveOtp(phone);
        smsService.sendSmsOtp(phone, code);
        return ResponseEntity.ok(Map.of("message", "OTP sent via SMS to " + phone));
    }

    @PostMapping("/forgot-username/verify")
    public ResponseEntity<?> verifyUsername(@RequestBody UsernameRecoveryRequest data) {
        String email = authService.recoverUsername(data.getPhoneNumber(), data.getOtpCode());
        return ResponseEntity.ok(Map.of("username", "Your email is: " + email));
    }

    @PostMapping("/logout")
    public ResponseEntity<?> logout(Authentication auth) {
        if (auth != null && auth.isAuthenticated()) {
            authService.recordLogout(auth.getName());
        }
        return ResponseEntity.ok(Map.of("message", "Logged out. Please discard the JWT on the client."));
    }
}