package com.cts.controller;

import com.cts.constants.Role;
import com.cts.constants.Status;
import com.cts.dao.AuditLogRepository;
import com.cts.entity.AuditLog;
import com.cts.dto.AuditLogRequest;
import com.cts.dto.UserPromotionDTO;
import com.cts.service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import com.cts.entity.User;
import com.cts.dao.UserRepository;
import com.cts.dao.DriverRepository;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/admin")
@PreAuthorize("hasRole('ADMIN')")
public class AdminController {

    private final UserService userService;
    private final UserRepository userRepository;
    private final AuditLogRepository auditLogRepository;
    private final DriverRepository driverRepository;

    public AdminController(UserService userService,
                           UserRepository userRepository,
                           AuditLogRepository auditLogRepository,
                           DriverRepository driverRepository) {
        this.userService = userService;
        this.userRepository = userRepository;
        this.auditLogRepository = auditLogRepository;
        this.driverRepository=driverRepository;
    }

    @GetMapping("/users")
    public ResponseEntity<List<User>> getAllUsers() {
        return ResponseEntity.ok(userRepository.findAll());
    }

    @GetMapping("/users/role/{role}")
    public ResponseEntity<List<User>> getUsersByRole(@PathVariable Role role) {
        return ResponseEntity.ok(userRepository.findByRole(role));
    }

    @GetMapping("/users/pending")
    public ResponseEntity<List<User>> getPendingUsers() {
        return ResponseEntity.ok(userRepository.findByStatus(Status.PENDING));
    }

    @GetMapping("/users/{id}/lookup")
    @PreAuthorize("hasAnyRole('ADMIN','DISPATCHER','FLEET_MANAGER')")
    public ResponseEntity<?> lookupUser(@PathVariable Long id) {
        return userRepository.findById(id)
                .<ResponseEntity<?>>map(u -> {
                    Map<String, Object> body = new java.util.LinkedHashMap<>();
                    body.put("userId", u.getUserId());
                    body.put("name", u.getName());
                    body.put("email", u.getEmail());
                    body.put("role", u.getRole() == null ? null : u.getRole().name());
                    body.put("status", u.getStatus() == null ? null : u.getStatus().name());
                    return ResponseEntity.ok(body);
                })
                .orElseGet(() -> ResponseEntity.status(404)
                        .body(Map.of("error", "No user found with id " + id)));
    }


    @PutMapping("/users/{id}/approve")
    public ResponseEntity<Map<String, String>> approveUser(@PathVariable Long id,
                                                           Authentication auth) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found"));
        if (user.getStatus() != Status.PENDING) {
            throw new RuntimeException("User is not in PENDING status. Current status: " + user.getStatus());
        }
        user.setStatus(Status.ACTIVE);
        userRepository.save(user);

        // If the approved user is a DRIVER, create their entry in the drivers table.
        if (user.getRole() == Role.DRIVER && driverRepository.findByUser(user).isEmpty()) {
            com.cts.entity.Driver driver = new com.cts.entity.Driver();
            driver.setUser(user);
            driver.setLicenseNumber("PENDING-" + user.getUserId());
            driver.setContactInfo(user.getPhoneNumber());
            driver.setStatus("AVAILABLE");
            driverRepository.save(driver);
        }

        userRepository.findByEmail(auth.getName()).ifPresent(admin ->
                auditLogRepository.save(new AuditLog(admin.getUserId(),
                        "REGISTRATION_APPROVED",
                        "Approved " + user.getEmail() + " as " + user.getRole())));

        return ResponseEntity.ok(Map.of("message",
                "User " + user.getEmail() + " approved as " + user.getRole()));
    }

    @PutMapping("/users/{id}/reject")
    public ResponseEntity<Map<String, String>> rejectUser(@PathVariable Long id,
                                                          Authentication auth) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found"));
        if (user.getStatus() != Status.PENDING) {
            throw new RuntimeException("User is not in PENDING status. Current status: " + user.getStatus());
        }

        String rejectedEmail = user.getEmail();
        Role rejectedRole = user.getRole();

        userRepository.delete(user);

        userRepository.findByEmail(auth.getName()).ifPresent(admin ->
                auditLogRepository.save(new AuditLog(admin.getUserId(),
                        "REGISTRATION_REJECTED",
                        "Rejected " + rejectedEmail + " (requested role " + rejectedRole + ")")));

        return ResponseEntity.ok(Map.of("message",
                "Registration request for " + rejectedEmail + " rejected."));
    }

    @PutMapping("/users/{id}/updateRole")
    public ResponseEntity<Map<String, String>> promoteUser(
            @PathVariable Long id,
            @RequestBody UserPromotionDTO dto,
            Authentication auth) {
        userService.promoteUser(id, dto);
        userRepository.findByEmail(auth.getName()).ifPresent(admin ->
                auditLogRepository.save(new AuditLog(admin.getUserId(),
                        "ROLE_UPDATE", "Role updated to: " + dto.getNewRole())));
        return ResponseEntity.ok(Map.of("message", "Role updated to " + dto.getNewRole()));
    }

    @PutMapping("/users/{id}/reactivate")
    public ResponseEntity<Map<String, String>> reactivateUser(
            @PathVariable Long id,
            Authentication auth) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found"));
        user.setStatus(Status.ACTIVE);
        userRepository.save(user);
        userRepository.findByEmail(auth.getName()).ifPresent(admin ->
                auditLogRepository.save(new AuditLog(admin.getUserId(),
                        "REACTIVATION", "Reactivated: " + user.getEmail())));
        return ResponseEntity.ok(Map.of("message", "User reactivated successfully."));
    }

    @DeleteMapping("/users/{id}")
    public ResponseEntity<Map<String, String>> deactivateUser(
            @PathVariable Long id,
            Authentication auth) {
        userService.deactivateUser(id);
        userRepository.findByEmail(auth.getName()).ifPresent(admin ->
                auditLogRepository.save(new AuditLog(admin.getUserId(),
                        "DEACTIVATION", "Deactivated user ID: " + id)));
        return ResponseEntity.ok(Map.of("message", "User deactivated successfully."));
    }

    @GetMapping("/audit-logs")
    @PreAuthorize("hasAnyRole('ADMIN','AUDITOR')")
    public ResponseEntity<List<AuditLog>> getAuditLogs() {
        return ResponseEntity.ok(auditLogRepository.findAllByOrderByTimestampDesc());
    }

    /**
     * INTERNAL endpoint — called by other microservices (via Feign) to write
     * an audit row into the central audit_logs table. Accepts any authenticated
     * call (since all services are behind the gateway and JWT-validated).
     */
    @PostMapping("/internal/audit-log")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<Map<String, String>> writeInternalAuditLog(@RequestBody AuditLogRequest request) {
        AuditLog log = new AuditLog(request.getUserId(), request.getAction(), request.getDetails());
        auditLogRepository.save(log);
        return ResponseEntity.ok(Map.of("status", "logged"));
    }
}
