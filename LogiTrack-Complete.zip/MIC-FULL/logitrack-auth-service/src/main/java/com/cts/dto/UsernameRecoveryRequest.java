package com.cts.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Request body for recovering username/email via phone number")
public class UsernameRecoveryRequest {

    @Schema(example = "9876543210", requiredMode = Schema.RequiredMode.REQUIRED)
    private String phoneNumber;

    @Schema(example = "123456", description = "OTP received via SMS", requiredMode = Schema.RequiredMode.REQUIRED)
    private String otpCode;
}