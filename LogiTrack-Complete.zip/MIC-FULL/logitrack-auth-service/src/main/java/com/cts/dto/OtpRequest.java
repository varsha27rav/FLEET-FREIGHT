package com.cts.dto;

import lombok.Data;

@Data
public class OtpRequest {
    private String email;
}