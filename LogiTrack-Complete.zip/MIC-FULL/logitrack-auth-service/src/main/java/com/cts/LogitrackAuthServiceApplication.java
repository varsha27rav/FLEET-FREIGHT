package com.cts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

@SpringBootApplication
@EnableJpaAuditing
public class LogitrackAuthServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(LogitrackAuthServiceApplication.class, args);
    }
}
