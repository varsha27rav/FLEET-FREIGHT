package com.cts.dto;

import io.swagger.v3.oas.annotations.media.Schema;

@Schema(description = "Response containing the generated authentication token")
public class JwtResponse {

    @Schema(description = "The JWT access token")
    private String token;

    @Schema(example = "Bearer", description = "The type of the token")
    private String type = "Bearer";

    public JwtResponse(String token) {
        this.token = token;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}