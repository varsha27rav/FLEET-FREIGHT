package com.cts.security;

import java.util.Objects;

public class AuthUser {

    private final String email;
    private final Long userId;
    private final String role;

    public AuthUser(String email, Long userId, String role) {
        this.email = email;
        this.userId = userId;
        this.role = role;
    }

    public String getEmail() { return email; }
    public Long getUserId() { return userId; }
    public String getRole() { return role; }

    @Override
    public String toString() { return email; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof AuthUser)) return false;
        AuthUser other = (AuthUser) o;
        return Objects.equals(email, other.email) && Objects.equals(userId, other.userId);
    }

    @Override
    public int hashCode() { return Objects.hash(email, userId); }
}
