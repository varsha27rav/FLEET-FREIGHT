package com.cts.service;

import com.cts.dao.OtpRepository; // Ensure you have this interface
import com.cts.entity.OtpEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.Random;

@Service
public class OtpService {

    private final OtpRepository otpRepository;

    public OtpService(OtpRepository otpRepository) {
        this.otpRepository = otpRepository;
    }

    @Transactional
    public String generateAndSaveOtp(String email) {
        // 1. Generate a 6-digit random code
        String code = String.format("%06d", new Random().nextInt(999999));

        // 2. Delete any existing OTPs for this email to prevent clutter
        otpRepository.deleteByEmail(email);

        // 3. Create new OTP (valid for 5 minutes)
        OtpEntity otpEntity = new OtpEntity(email, code, 5);
        otpRepository.save(otpEntity);

        // For testing/console output
        System.out.println("DEBUG: Generated OTP for " + email + " is: " + code);

        return code;
    }

    public boolean validateOtp(String email, String code) {
        Optional<OtpEntity> otpOpt = otpRepository.findByEmailAndCode(email, code);

        if (otpOpt.isPresent()) {
            OtpEntity otp = otpOpt.get();
            // Check if current time is before expiry
            if (otp.getExpiryDate().isAfter(LocalDateTime.now())) {
                // Optional: Delete after successful validation so it can't be reused
                otpRepository.delete(otp);
                return true;
            }
        }
        return false;
    }
}