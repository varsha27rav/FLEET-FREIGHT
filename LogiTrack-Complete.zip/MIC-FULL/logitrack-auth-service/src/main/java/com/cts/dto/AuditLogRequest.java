package com.cts.dto;

/**
 * AuditLogRequest
 * ----------------
 * Payload accepted by the internal audit endpoint (POST /api/admin/internal/audit-log).
 * Used by other microservices (via Feign) to write audit rows into the Auth Service DB.
 */
public class AuditLogRequest {
    private Long userId;
    private String action;
    private String details;

    public AuditLogRequest() {}

    public AuditLogRequest(Long userId, String action, String details) {
        this.userId = userId;
        this.action = action;
        this.details = details;
    }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public String getAction() { return action; }
    public void setAction(String action) { this.action = action; }

    public String getDetails() { return details; }
    public void setDetails(String details) { this.details = details; }
}
