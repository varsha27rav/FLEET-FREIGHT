package com.cts.dto;

import lombok.Data;

@Data
public class PhoneOtpRequest {
    private String phoneNumber;
}