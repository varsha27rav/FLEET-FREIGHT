package com.cts.dao;

import com.cts.constants.Role;
import com.cts.constants.Status;
import com.cts.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByEmail(String email);
    Optional<User> findByPhoneNumber(String phoneNumber);
    boolean existsByEmail(String email);
    List<User> findByRole(Role role);
    List<User> findByStatus(Status status);
}
