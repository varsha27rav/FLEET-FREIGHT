package com.cts.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Request body for resetting user password")
public class PasswordResetRequest {

    @Schema(example = "user@example.com", requiredMode = Schema.RequiredMode.REQUIRED)
    private String email;

    @Schema(example = "123456", description = "OTP received via email", requiredMode = Schema.RequiredMode.REQUIRED)
    private String otpCode;

    @Schema(example = "NewSecurePass123!", requiredMode = Schema.RequiredMode.REQUIRED)
    private String newPassword;
}