package com.cts.service;

import com.cts.constants.Role;
import com.cts.constants.Status;
import com.cts.dao.DriverRepository;
import com.cts.dto.UserPromotionDTO;
import com.cts.entity.Driver;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.cts.entity.User;
import com.cts.dao.UserRepository;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final DriverRepository driverRepository;

    public UserService(UserRepository userRepository, DriverRepository driverRepository) {
        this.userRepository = userRepository;
        this.driverRepository = driverRepository;
    }

    @Transactional
    public void promoteUser(Long userId, UserPromotionDTO promotionDTO) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        Role newRole = promotionDTO.getNewRole();

        // 1. VALIDATION: Allow moving TO Customer from any role,
        // but block moving between two specialized roles (e.g., Driver -> Dispatcher)
        if (newRole != Role.CUSTOMER && user.getRole() != Role.CUSTOMER && user.getRole() != newRole) {
            throw new RuntimeException("User already has the role: " + user.getRole() +
                    ". Please demote them to CUSTOMER before reassignment.");
        }

        // 2. Update the User's Role in the users table
        user.setRole(newRole);
        user.setStatus(Status.ACTIVE);
        userRepository.save(user);

        // 3. Handle specialized profile logic and CLEANUP
        switch (newRole) {
            case DRIVER:
                handleDriverLogic(user, promotionDTO);
                break;

            case CUSTOMER:
                // Explicitly clean up specialized tables if moving back to Customer
                System.out.println("Demoting user to Customer. Cleaning up profiles...");
                cleanUpOldProfiles(user);
                break;

            case DISPATCHER:
            case FLEET_MANAGER:
            case AUDITOR:
            case ADMIN:
                cleanUpOldProfiles(user);
                break;

            default:
                break;
        }
    }

    private void handleDriverLogic(User user, UserPromotionDTO dto) {
        Driver driver = driverRepository.findByUser(user).orElse(new Driver());

        driver.setUser(user);
        driver.setLicenseNumber(dto.getLicenseNumber());

        String contact = (dto.getContactInfo() != null && !dto.getContactInfo().isEmpty())
                ? dto.getContactInfo()
                : user.getPhoneNumber();

        driver.setContactInfo(contact);
        driver.setStatus("AVAILABLE");

        driverRepository.save(driver);
    }

    private void cleanUpOldProfiles(User user) {
        // If a user is promoted to a non-driver role, remove their driver profile if it exists
        driverRepository.findByUser(user).ifPresent(driverRepository::delete);
    }

    @Transactional
    public void deactivateUser(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found with ID: " + userId));

        // 1. Set status to INACTIVE
        user.setStatus(Status.INACTIVE);

        // 2. Optional: Reset role to CUSTOMER so they don't appear in Dispatcher/Driver lists
        user.setRole(Role.CUSTOMER);

        userRepository.save(user);

        // 3. Clean up specialized profiles (removes them from 'drivers' table)
        cleanUpOldProfiles(user);

        System.out.println("User " + userId + " has been deactivated and removed from specialized roles.");
    }
}