package com.cts.controller;

import com.cts.client.AuditClient;
import com.cts.dto.AuditLogRequest;
import com.cts.security.AuthUser;
import com.cts.dao.ShipmentRepository;
import com.cts.dto.ShipmentRequest;
import com.cts.entity.Shipment;
import com.cts.service.ShipmentService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/shipments")
public class ShipmentController {

    private final ShipmentService shipmentService;
    private final ShipmentRepository shipmentRepository;
    private final AuditClient auditClient;

    public ShipmentController(ShipmentService shipmentService,
                              ShipmentRepository shipmentRepository,
                              AuditClient auditClient) {
        this.shipmentService = shipmentService;
        this.shipmentRepository = shipmentRepository;
        this.auditClient = auditClient;
    }

    private Long currentUserId(Authentication auth) {
        try {
            if (auth != null && auth.getPrincipal() instanceof AuthUser u) {
                return u.getUserId();
            }
        } catch (Exception ignored) {}
        return null;
    }

    private void audit(Long userId, String action, String details) {
        try {
            auditClient.writeAudit(new AuditLogRequest(userId, action, details));
        } catch (Exception ignored) {}
    }

    @PostMapping("/create")
    @PreAuthorize("hasRole('CUSTOMER')")
    public ResponseEntity<Shipment> placeOrder(Authentication authentication,
                                               @RequestBody ShipmentRequest request) {
        AuthUser caller = (AuthUser) authentication.getPrincipal();
        return ResponseEntity.ok(shipmentService.createShipment(caller.getUserId(), request));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('CUSTOMER', 'ADMIN', 'DISPATCHER', 'DRIVER')")
    public ResponseEntity<Shipment> trackShipment(@PathVariable Long id) {
        return ResponseEntity.ok(shipmentService.getShipmentStatus(id));
    }

    @GetMapping("/my-orders")
    @PreAuthorize("hasRole('CUSTOMER')")
    public ResponseEntity<List<Shipment>> getMyOrders(Authentication authentication) {
        AuthUser caller = (AuthUser) authentication.getPrincipal();
        return ResponseEntity.ok(shipmentService.getCustomerShipments(caller.getUserId()));
    }

    @GetMapping("/all")
    @PreAuthorize("hasAnyRole('ADMIN', 'DISPATCHER','CUSTOMER')")
    public ResponseEntity<List<Shipment>> getAllShipments() {
        return ResponseEntity.ok(shipmentRepository.findAll());
    }

    @PutMapping("/{id}/status")
    public ResponseEntity<?> updateShipmentStatus(@PathVariable Long id,
                                                  @RequestBody String status,
                                                  Authentication auth) {
        Shipment shipment = shipmentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Shipment not found"));
        Shipment.ShipmentStatus oldStatus = shipment.getStatus();
        shipment.setStatus(Shipment.ShipmentStatus.valueOf(status));
        shipmentRepository.save(shipment);

        audit(currentUserId(auth), "SHIPMENT_STATUS_UPDATED",
                "Shipment #" + id + " status changed from " + oldStatus + " to " + status);

        return ResponseEntity.ok().build();
    }

    @PostMapping("/{id}/verify-delivery")
    @PreAuthorize("hasRole('DRIVER')")
    public ResponseEntity<?> verifyDelivery(@PathVariable Long id,
                                            @RequestBody Map<String, String> body,
                                            Authentication auth) {
        String inputOtp = body.get("otp");
        Shipment shipment = shipmentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Shipment not found"));

        if (shipment.getDeliveryOtp().equals(inputOtp)) {
            shipment.setStatus(Shipment.ShipmentStatus.DELIVERED);
            shipmentRepository.save(shipment);

            audit(currentUserId(auth), "DELIVERY_OTP_VERIFIED",
                    "Driver verified delivery OTP for Shipment #" + id);

            return ResponseEntity.ok(Map.of("message", "Delivery successful! Status updated to DELIVERED."));
        } else {
            audit(currentUserId(auth), "DELIVERY_OTP_FAILED",
                    "Invalid OTP entered for Shipment #" + id);
            return ResponseEntity.status(400).body(Map.of("message", "Invalid OTP. Delivery could not be verified."));
        }
    }

    @PostMapping("/{id}/regenerate-otp")
    @PreAuthorize("hasAnyRole('ADMIN','DISPATCHER','CUSTOMER')")
    public ResponseEntity<?> regenerateDeliveryOtp(@PathVariable Long id, Authentication auth) {
        Shipment shipment = shipmentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Shipment not found"));
        String otp = String.format("%06d", new java.security.SecureRandom().nextInt(1_000_000));
        shipment.setDeliveryOtp(otp);
        shipmentRepository.save(shipment);

        audit(currentUserId(auth), "DELIVERY_OTP_REGENERATED",
                "Delivery OTP regenerated for Shipment #" + id);

        return ResponseEntity.ok(Map.of("shipmentId", id, "deliveryOtp", otp));
    }
}
