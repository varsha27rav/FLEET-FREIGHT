package com.cts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

@EnableFeignClients
@EnableJpaAuditing
@SpringBootApplication
public class LogitrackShipmentServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(LogitrackShipmentServiceApplication.class, args);
    }
}
