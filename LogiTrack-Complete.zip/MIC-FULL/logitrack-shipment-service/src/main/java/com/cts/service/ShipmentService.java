package com.cts.service;

import com.cts.client.AuditClient;
import com.cts.dto.AuditLogRequest;
import com.cts.dao.ShipmentRepository;
import com.cts.dto.ShipmentRequest;
import com.cts.entity.Shipment;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.security.SecureRandom;
import java.util.List;

@Service
public class ShipmentService {

    private final ShipmentRepository shipmentRepository;
    private final AuditClient auditClient;
    private static final SecureRandom OTP_RANDOM = new SecureRandom();

    public ShipmentService(ShipmentRepository shipmentRepository,
                           AuditClient auditClient) {
        this.shipmentRepository = shipmentRepository;
        this.auditClient = auditClient;
    }

    @Transactional
    public Shipment createShipment(Long customerUserId, ShipmentRequest request) {
        Shipment shipment = new Shipment();
        shipment.setCustomerId(customerUserId);
        shipment.setOrigin(request.getOrigin());
        shipment.setDestination(request.getDestination());
        shipment.setWeight(request.getWeight());
        shipment.setReceiverName(request.getReceiverName());
        shipment.setReceiverPhone(request.getReceiverPhone());
        shipment.setStatus(Shipment.ShipmentStatus.PENDING);
        shipment.setDeliveryOtp(String.format("%06d", OTP_RANDOM.nextInt(1_000_000)));

        Shipment saved = shipmentRepository.save(shipment);

        // Audit via central Auth Service
        try {
            auditClient.writeAudit(new AuditLogRequest(customerUserId, "SHIPMENT_CREATED",
                    "Order #" + saved.getShipmentId() + " placed from " + saved.getOrigin()
                            + " to " + saved.getDestination()));
        } catch (Exception ignored) {
            // Fallback handles silently
        }

        return saved;
    }

    public Shipment getShipmentStatus(Long shipmentId) {
        return shipmentRepository.findById(shipmentId)
                .orElseThrow(() -> new RuntimeException("Shipment not found"));
    }

    public List<Shipment> getCustomerShipments(Long customerUserId) {
        return shipmentRepository.findByCustomerId(customerUserId);
    }
}
