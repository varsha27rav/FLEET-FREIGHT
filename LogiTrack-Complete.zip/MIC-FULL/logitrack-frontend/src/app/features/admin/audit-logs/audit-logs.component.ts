import { Component, OnInit, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminService } from '../../../core/services/admin.service';
import { AuditLog } from '../../../core/models/user.model';

@Component({
  selector: 'app-audit-logs',
  standalone: true,
  imports: [CommonModule],
  template: `
  <div class="page">
    <div class="page-header">
      <div>
        <h1 class="page-title">Audit Logs</h1>
        <p class="page-subtitle">System activity, newest first.</p>
      </div>
    </div>

    <div *ngIf="error()" class="alert alert-error">{{ error() }}</div>
    <div class="card">
      <div class="spinner-center" *ngIf="loading()"><span class="spinner spinner-lg"></span></div>

      <div *ngIf="!loading() && logs().length === 0" class="empty-state"><h4>No audit logs</h4></div>

      <div class="table-wrapper" *ngIf="!loading() && logs().length > 0">
        <table class="table">
          <thead><tr><th>#</th><th>User</th><th>Action</th><th>Details</th><th>Timestamp</th></tr></thead>
          <tbody>
            <tr *ngFor="let l of logs()">
              <td>#{{ l.auditId }}</td>
              <td>{{ l.userId }}</td>
              <td><span class="badge badge-info">{{ l.action }}</span></td>
              <td>{{ l.details }}</td>
              <td>{{ l.timestamp | date:'medium' }}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
  `
})
export class AuditLogsComponent implements OnInit {
  private svc = inject(AdminService);
  loading = signal(true);
  error = signal<string | null>(null);
  logs = signal<AuditLog[]>([]);

  ngOnInit() {
    this.svc.auditLogs().subscribe({
      next: r => { this.logs.set(r); this.loading.set(false); },
      error: e => { this.error.set(e.error?.message || 'Failed.'); this.loading.set(false); }
    });
  }
}
