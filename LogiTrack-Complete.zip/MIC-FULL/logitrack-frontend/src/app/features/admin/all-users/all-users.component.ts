import { Component, OnInit, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';
import { AdminService } from '../../../core/services/admin.service';
import { User } from '../../../core/models/user.model';
import { Role } from '../../../core/models/role.model';

@Component({
  selector: 'app-all-users',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  template: `
  <div class="page">
    <div class="page-header">
      <div>
        <h1 class="page-title">All Users</h1>
        <p class="page-subtitle">Every registered account.</p>
      </div>
    </div>

    <div *ngIf="error()" class="alert alert-error">{{ error() }}</div>
    <div *ngIf="success()" class="alert alert-success">{{ success() }}</div>

    <div class="card">
      <div class="card-header" style="border-bottom: 0; padding-bottom: 0;">
        <h3 class="card-title">
          {{ filterRole() ? filterRole() + ' users' : 'All users' }}
          ({{ users().length }})
        </h3>
        <div style="display:flex; gap: 8px; align-items: center;">
          <label class="form-label" style="margin-bottom:0;">Filter by role:</label>
          <select class="form-control" style="width:auto;"
                  [value]="filterRole() || ''"
                  (change)="onFilter($event)">
            <option value="">All roles</option>
            <option *ngFor="let r of allRoles" [value]="r">{{ r }}</option>
          </select>
        </div>
      </div>
      <div class="spinner-center" *ngIf="loading()"><span class="spinner spinner-lg"></span></div>

      <div class="table-wrapper" *ngIf="!loading()">
        <table class="table">
          <thead><tr><th>#</th><th>Name</th><th>Email</th><th>Phone</th><th>Role</th><th>Status</th><th>Actions</th></tr></thead>
          <tbody>
            <tr *ngFor="let u of users()">
              <td>#{{ u.userId }}</td>
              <td>{{ u.name }}</td>
              <td>{{ u.email }}</td>
              <td>{{ u.phoneNumber }}</td>
              <td><span class="badge badge-info">{{ u.role }}</span></td>
              <td><span class="badge" [ngClass]="badge(u.status)">{{ u.status }}</span></td>
              <td>
                <button *ngIf="u.status === 'ACTIVE'"
                        class="btn btn-secondary btn-sm" (click)="openRole(u)">Change role</button>
                <button *ngIf="u.status === 'ACTIVE'"
                        class="btn btn-danger btn-sm" (click)="deactivate(u)" style="margin-left:6px;">Deactivate</button>
                <button *ngIf="u.status === 'INACTIVE'"
                        class="btn btn-success btn-sm" (click)="reactivate(u)">Reactivate</button>
                <span *ngIf="u.status === 'PENDING'" style="color: var(--text-muted);">Pending approval</span>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- Change Role modal -->
    <div *ngIf="roleTarget()" class="modal-backdrop" (click)="cancelRole()">
      <div class="modal-card" (click)="$event.stopPropagation()">
        <h3>Change role for {{ roleTarget()?.email }}</h3>
        <p class="card-subtitle">Current: <strong>{{ roleTarget()?.role }}</strong></p>
        <form [formGroup]="roleForm" (ngSubmit)="confirmRole()">
          <div class="form-group">
            <label class="form-label">New role</label>
            <select class="form-control" formControlName="newRole">
              <option *ngFor="let r of selectableRoles" [value]="r">{{ r }}</option>
            </select>
            <div class="form-error" style="color: var(--text-muted); margin-top: 6px;">
              Backend rule: you can only move TO/FROM CUSTOMER. Specialist→specialist requires demoting to CUSTOMER first.
            </div>
          </div>

          <ng-container *ngIf="roleForm.controls.newRole.value === 'DRIVER'">
            <div class="form-row">
              <div class="form-group">
                <label class="form-label">License number</label>
                <input class="form-control" formControlName="licenseNumber" placeholder="DL1234567"/>
              </div>
              <div class="form-group">
                <label class="form-label">Contact info</label>
                <input class="form-control" formControlName="contactInfo" placeholder="9876543210"/>
              </div>
            </div>
          </ng-container>

          <div style="display:flex; gap:8px;">
            <button type="submit" class="btn btn-primary" [disabled]="saving()">Apply</button>
            <button type="button" class="btn btn-secondary" (click)="cancelRole()">Cancel</button>
          </div>
        </form>
      </div>
    </div>
  </div>
  `,
  styles: [`
    .modal-backdrop {
      position: fixed; inset: 0; background: rgba(15, 23, 42, 0.45);
      display: flex; align-items: center; justify-content: center; z-index: 100;
    }
    .modal-card {
      background: var(--surface); border-radius: 12px; padding: 24px 28px;
      width: 100%; max-width: 520px; box-shadow: var(--shadow);
    }
    .modal-card h3 { margin: 0 0 10px; font-size: 18px; }
  `]
})
export class AllUsersComponent implements OnInit {
  private fb = inject(FormBuilder);
  private svc = inject(AdminService);

  loading = signal(true);
  saving = signal(false);
  error = signal<string | null>(null);
  success = signal<string | null>(null);
  users = signal<User[]>([]);

  roleTarget = signal<User | null>(null);
  selectableRoles: Role[] = ['CUSTOMER', 'DRIVER', 'DISPATCHER', 'FLEET_MANAGER', 'AUDITOR'];

  // Filter on All Users page — uses /api/admin/users/role/{role}
  allRoles: Role[] = ['ADMIN', 'CUSTOMER', 'DRIVER', 'DISPATCHER', 'FLEET_MANAGER', 'AUDITOR'];
  filterRole = signal<Role | ''>('');

  roleForm = this.fb.nonNullable.group({
    newRole: ['CUSTOMER' as Role, Validators.required],
    licenseNumber: [''],
    contactInfo: ['']
  });

  ngOnInit() { this.load(); }

  load() {
    this.loading.set(true);
    const role = this.filterRole();
    const obs = role ? this.svc.getByRole(role as Role) : this.svc.getAllUsers();
    obs.subscribe({
      next: r => { this.users.set(r); this.loading.set(false); },
      error: (e: HttpErrorResponse) => { this.error.set(this.msg(e)); this.loading.set(false); }
    });
  }

  onFilter(ev: Event) {
    const value = (ev.target as HTMLSelectElement).value;
    this.filterRole.set(value as Role | '');
    this.load();
  }

  openRole(u: User) {
    this.error.set(null); this.success.set(null);
    this.roleTarget.set(u);
    this.roleForm.reset({ newRole: 'CUSTOMER' as Role, licenseNumber: '', contactInfo: u.phoneNumber || '' });
  }
  cancelRole() { this.roleTarget.set(null); }
  confirmRole() {
    if (this.roleForm.invalid) { this.roleForm.markAllAsTouched(); return; }
    const u = this.roleTarget(); if (!u) return;
    this.saving.set(true);
    const v = this.roleForm.getRawValue();
    this.svc.updateRole(u.userId, {
      newRole: v.newRole,
      licenseNumber: v.licenseNumber || undefined,
      contactInfo: v.contactInfo || undefined
    }).subscribe({
      next: r => { this.saving.set(false); this.success.set(r.message); this.roleTarget.set(null); this.load(); },
      error: (e: HttpErrorResponse) => { this.saving.set(false); this.error.set(this.msg(e)); }
    });
  }

  deactivate(u: User) {
    if (!confirm(`Deactivate ${u.email}? Their role will be reset to CUSTOMER and they won't be able to log in.`)) return;
    this.error.set(null); this.success.set(null);
    this.svc.deactivate(u.userId).subscribe({
      next: r => { this.success.set(r.message); this.load(); },
      error: (e: HttpErrorResponse) => this.error.set(this.msg(e))
    });
  }

  reactivate(u: User) {
    if (!confirm(`Reactivate ${u.email}?`)) return;
    this.error.set(null); this.success.set(null);
    this.svc.reactivate(u.userId).subscribe({
      next: r => { this.success.set(r.message); this.load(); },
      error: (e: HttpErrorResponse) => this.error.set(this.msg(e))
    });
  }

  badge(s: string) { return s === 'ACTIVE' ? 'badge-success' : s === 'PENDING' ? 'badge-warning' : 'badge-danger'; }
  private msg(e: HttpErrorResponse) { return e.error?.message || e.error?.error || e.message || 'Failed'; }
}
