import { Component, OnInit, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { AdminService } from '../../../core/services/admin.service';
import { User } from '../../../core/models/user.model';

@Component({
  selector: 'app-pending-users',
  standalone: true,
  imports: [CommonModule],
  template: `
  <div class="page">
    <div class="page-header">
      <div>
        <h1 class="page-title">Pending Users</h1>
        <p class="page-subtitle">Approve or reject account requests.</p>
      </div>
    </div>

    <div *ngIf="error()" class="alert alert-error">{{ error() }}</div>
    <div *ngIf="message()" class="alert alert-success">{{ message() }}</div>

    <div class="card">
      <div class="spinner-center" *ngIf="loading()"><span class="spinner spinner-lg"></span></div>

      <div *ngIf="!loading() && users().length === 0" class="empty-state">
        <h4>No pending users</h4><p>All requests have been processed.</p>
      </div>

      <div class="table-wrapper" *ngIf="!loading() && users().length > 0">
        <table class="table">
          <thead><tr><th>#</th><th>Name</th><th>Email</th><th>Phone</th><th>Requested Role</th><th>Actions</th></tr></thead>
          <tbody>
            <tr *ngFor="let u of users()">
              <td>#{{ u.userId }}</td>
              <td>{{ u.name }}</td>
              <td>{{ u.email }}</td>
              <td>{{ u.phoneNumber }}</td>
              <td><span class="badge badge-info">{{ u.role }}</span></td>
              <td>
                <button class="btn btn-success btn-sm" (click)="approve(u.userId)">Approve</button>
                <button class="btn btn-danger btn-sm" (click)="reject(u.userId)" style="margin-left:6px;">Reject</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
  `
})
export class PendingUsersComponent implements OnInit {
  private svc = inject(AdminService);
  loading = signal(true);
  error = signal<string | null>(null);
  message = signal<string | null>(null);
  users = signal<User[]>([]);

  ngOnInit() { this.load(); }

  load() {
    this.loading.set(true);
    this.svc.getPending().subscribe({
      next: r => { this.users.set(r); this.loading.set(false); },
      error: e => { this.error.set(this.msg(e)); this.loading.set(false); }
    });
  }

  approve(id: number) {
    this.svc.approve(id).subscribe({
      next: r => { this.message.set(r.message); this.load(); },
      error: e => this.error.set(this.msg(e))
    });
  }

  reject(id: number) {
    if (!confirm('Reject this registration?')) return;
    this.svc.reject(id).subscribe({
      next: r => { this.message.set(r.message); this.load(); },
      error: e => this.error.set(this.msg(e))
    });
  }

  private msg(e: HttpErrorResponse) { return e.error?.message || e.error?.error || e.message || 'Failed'; }
}
