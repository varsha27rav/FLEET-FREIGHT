package com.cts.controller;

import com.cts.dto.*;
import com.cts.entity.InspectionRecord;
import com.cts.entity.MaintenanceRecord;
import com.cts.entity.Vehicle;
import com.cts.service.FleetService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/fleet")
@PreAuthorize("hasRole('FLEET_MANAGER')")
public class FleetController {

    private final FleetService fleetService;

    public FleetController(FleetService fleetService) {
        this.fleetService = fleetService;
    }

    // --- Vehicle Management ---

    @PostMapping("/vehicles")
    public ResponseEntity<Vehicle> addVehicle(@Valid @RequestBody VehicleRequest dto) {
        return ResponseEntity.ok(fleetService.addVehicle(dto));
    }

    @PutMapping("/vehicles/{id}")
    public ResponseEntity<Vehicle> updateVehicle(@PathVariable Long id, @Valid @RequestBody VehicleRequest dto) {
        return ResponseEntity.ok(fleetService.updateVehicle(id, dto));
    }

    @DeleteMapping("/vehicles/{id}")
    public ResponseEntity<Map<String, String>> deleteVehicle(@PathVariable Long id) {
        fleetService.deleteVehicle(id);
        return ResponseEntity.ok(Map.of("message", "Vehicle deleted successfully."));
    }

    @GetMapping("/vehicles")
    public ResponseEntity<List<Vehicle>> getVehicles() {
        return ResponseEntity.ok(fleetService.getAllVehicles());
    }


    @GetMapping("/vehicles/{id}")
    @PreAuthorize("hasAnyRole('FLEET_MANAGER','DISPATCHER','ADMIN')")
    public ResponseEntity<Vehicle> getVehicleById(@PathVariable Long id) {
        return ResponseEntity.ok(fleetService.getVehicleById(id));
    }

    // --- Inspection ---

    @PostMapping("/inspections")
    public ResponseEntity<Map<String, String>> recordInspection(@Valid @RequestBody InspectionRequest dto) {
        fleetService.recordInspection(dto);
        return ResponseEntity.ok(Map.of("message", "Inspection recorded. Maintenance ticket created if failed."));
    }

    // --- Maintenance ---

    @PatchMapping("/maintenance/{id}/start")
    public ResponseEntity<Map<String, String>> startMaintenance(
            @PathVariable Long id,
            @RequestParam String mechanicName) {
        fleetService.startMaintenance(id, mechanicName);
        return ResponseEntity.ok(Map.of("message", "Maintenance started. Vehicle status: IN_MAINTENANCE."));
    }

    @PatchMapping("/maintenance/{id}/complete")
    public ResponseEntity<Map<String, String>> completeMaintenance(
            @PathVariable Long id,
            @Valid @RequestBody MaintenanceCompleteRequest dto) {
        fleetService.completeMaintenance(id, dto);
        return ResponseEntity.ok(Map.of("message", "Maintenance completed. Vehicle status: AVAILABLE."));
    }

    // --- INSPECTION RETRIEVAL ---

    /**
     * Get all inspection records across the entire fleet.
     */
    @GetMapping("/inspections")
    public ResponseEntity<List<InspectionRecord>> getAllInspections() {
        return ResponseEntity.ok(fleetService.getAllInspections());
    }

    /**
     * Get all inspections for a specific vehicle.
     */
    @GetMapping("/vehicles/{vehicleId}/inspections")
    public ResponseEntity<List<InspectionRecord>> getVehicleInspections(@PathVariable Long vehicleId) {
        return ResponseEntity.ok(fleetService.getInspectionsByVehicle(vehicleId));
    }

    // --- MAINTENANCE RETRIEVAL ---

    /**
     * Get all maintenance records across the entire fleet.
     */
    @GetMapping("/maintenance")
    public ResponseEntity<List<MaintenanceRecord>> getAllMaintenance() {
        return ResponseEntity.ok(fleetService.getAllMaintenanceRecords());
    }

    /**
     * Get all maintenance history for a specific vehicle.
     */
    @GetMapping("/vehicles/{vehicleId}/maintenance")
    public ResponseEntity<List<MaintenanceRecord>> getVehicleMaintenance(@PathVariable Long vehicleId) {
        return ResponseEntity.ok(fleetService.getMaintenanceByVehicle(vehicleId));
    }
}