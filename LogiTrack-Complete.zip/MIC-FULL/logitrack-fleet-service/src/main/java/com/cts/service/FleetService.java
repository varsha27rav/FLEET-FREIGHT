package com.cts.service;

import com.cts.client.AuditClient;
import com.cts.dao.VehicleRepository;
import com.cts.dao.InspectionRepository;
import com.cts.dao.MaintenanceRepository;
import com.cts.dto.AuditLogRequest;
import com.cts.dto.InspectionRequest;
import com.cts.dto.MaintenanceCompleteRequest;
import com.cts.dto.VehicleRequest;
import com.cts.entity.Vehicle;
import com.cts.entity.InspectionRecord;
import com.cts.entity.MaintenanceRecord;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class FleetService {

    private final VehicleRepository vehicleRepository;
    private final InspectionRepository inspectionRepository;
    private final MaintenanceRepository maintenanceRepository;
    private final AuditClient auditClient;

    public FleetService(VehicleRepository vehicleRepository,
                        InspectionRepository inspectionRepository,
                        MaintenanceRepository maintenanceRepository,
                        AuditClient auditClient) {
        this.vehicleRepository = vehicleRepository;
        this.inspectionRepository = inspectionRepository;
        this.maintenanceRepository = maintenanceRepository;
        this.auditClient = auditClient;
    }

    private Long currentUserId() {
        try {
            var auth = SecurityContextHolder.getContext().getAuthentication();
            if (auth != null && auth.getPrincipal() instanceof com.cts.security.AuthUser u) {
                return u.getUserId();
            }
        } catch (Exception ignored) {}
        return null;
    }

    private void audit(String action, String details) {
        try {
            auditClient.writeAudit(new AuditLogRequest(currentUserId(), action, details));
        } catch (Exception ignored) {}
    }

    // --- Vehicle Management ---

    @Transactional
    public Vehicle addVehicle(VehicleRequest dto) {
        Vehicle vehicle = new Vehicle();
        vehicle.setRegNumber(dto.getRegNumber());
        vehicle.setType(dto.getType());
        vehicle.setCapacity(dto.getCapacity());
        vehicle.setStatus(Vehicle.VehicleStatus.AVAILABLE);
        Vehicle saved = vehicleRepository.save(vehicle);

        audit("VEHICLE_CREATED",
                "Vehicle " + saved.getRegNumber() + " (" + saved.getType() + ") added to fleet");
        return saved;
    }

    @Transactional
    public Vehicle updateVehicle(Long id, VehicleRequest dto) {
        Vehicle vehicle = vehicleRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Vehicle not found"));
        vehicle.setRegNumber(dto.getRegNumber());
        vehicle.setType(dto.getType());
        vehicle.setCapacity(dto.getCapacity());
        Vehicle saved = vehicleRepository.save(vehicle);

        audit("VEHICLE_UPDATED",
                "Vehicle #" + id + " updated to " + saved.getRegNumber());
        return saved;
    }

    @Transactional
    public void deleteVehicle(Long id) {
        vehicleRepository.deleteById(id);
        audit("VEHICLE_DELETED", "Vehicle #" + id + " removed from fleet");
    }

    public List<Vehicle> getAllVehicles() {
        return vehicleRepository.findAll();
    }

    public Vehicle getVehicleById(Long id) {
        return vehicleRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Vehicle not found: " + id));
    }

    // --- Inspection & Maintenance Workflow ---

    @Transactional
    public void recordInspection(InspectionRequest dto) {
        InspectionRecord record = new InspectionRecord();
        record.setVehicleId(dto.getVehicleId());
        record.setConditionRating(dto.getConditionRating());
        record.setFindings(dto.getFindings());
        record.setPhotoUri(dto.getPhotoUri());
        record.setStatus(InspectionRecord.InspectionStatus.valueOf(dto.getStatus().toUpperCase()));
        record.setPerformedAt(LocalDateTime.now());

        InspectionRecord savedInspection = inspectionRepository.save(record);

        audit("INSPECTION_RECORDED",
                "Inspection recorded for Vehicle #" + dto.getVehicleId() +
                        " with status " + savedInspection.getStatus());

        if (savedInspection.getStatus() == InspectionRecord.InspectionStatus.FAILED) {
            MaintenanceRecord maint = new MaintenanceRecord();
            maint.setVehicleId(dto.getVehicleId());
            maint.setInspectionId(savedInspection.getInspectionId());
            maint.setTaskDescription("AUTO-GENERATED: Failed Inspection. Findings: " + dto.getFindings());
            maint.setStatus(MaintenanceRecord.MaintenanceStatus.PENDING);
            MaintenanceRecord savedMaint = maintenanceRepository.save(maint);

            audit("MAINTENANCE_CREATED",
                    "Auto-created maintenance ticket #" + savedMaint.getMaintId()
                            + " for failed inspection on Vehicle #" + dto.getVehicleId());
        }
    }

    @Transactional
    public void startMaintenance(Long maintId, String mechanicName) {
        MaintenanceRecord maint = maintenanceRepository.findById(maintId)
                .orElseThrow(() -> new RuntimeException("Maintenance ticket not found"));

        maint.setStatus(MaintenanceRecord.MaintenanceStatus.IN_PROGRESS);
        maint.setPerformedBy(mechanicName);
        maint.setPerformedAt(LocalDateTime.now());
        maintenanceRepository.save(maint);

        Vehicle vehicle = vehicleRepository.findById(maint.getVehicleId())
                .orElseThrow(() -> new RuntimeException("Vehicle not found"));
        vehicle.setStatus(Vehicle.VehicleStatus.IN_MAINTENANCE);
        vehicleRepository.save(vehicle);

        audit("MAINTENANCE_STATUS_UPDATED",
                "Maintenance #" + maintId + " started by " + mechanicName +
                        ". Vehicle #" + vehicle.getVehicleId() + " set to IN_MAINTENANCE");
    }

    @Transactional
    public void completeMaintenance(Long maintId, MaintenanceCompleteRequest dto) {
        MaintenanceRecord maint = maintenanceRepository.findById(maintId)
                .orElseThrow(() -> new RuntimeException("Maintenance ticket not found"));

        maint.setStatus(MaintenanceRecord.MaintenanceStatus.COMPLETED);
        maint.setCost(dto.getCost());
        maint.setMechanicNotes(dto.getMechanicNotes());
        maintenanceRepository.save(maint);

        Vehicle vehicle = vehicleRepository.findById(maint.getVehicleId())
                .orElseThrow(() -> new RuntimeException("Vehicle not found"));
        vehicle.setStatus(Vehicle.VehicleStatus.AVAILABLE);
        vehicleRepository.save(vehicle);

        audit("MAINTENANCE_STATUS_UPDATED",
                "Maintenance #" + maintId + " completed. Cost: " + dto.getCost() +
                        ". Vehicle #" + vehicle.getVehicleId() + " back to AVAILABLE");
    }

    public List<InspectionRecord> getAllInspections() {
        return inspectionRepository.findAll();
    }

    public List<InspectionRecord> getInspectionsByVehicle(Long vehicleId) {
        return inspectionRepository.findByVehicleId(vehicleId);
    }

    public List<MaintenanceRecord> getAllMaintenanceRecords() {
        return maintenanceRepository.findAll();
    }

    public List<MaintenanceRecord> getMaintenanceByVehicle(Long vehicleId) {
        return maintenanceRepository.findByVehicleId(vehicleId);
    }
}
