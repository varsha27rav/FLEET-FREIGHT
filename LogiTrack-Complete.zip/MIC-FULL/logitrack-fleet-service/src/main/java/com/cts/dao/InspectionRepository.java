package com.cts.dao;

import com.cts.entity.InspectionRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface InspectionRepository extends JpaRepository<InspectionRecord, Long> {
    List<InspectionRecord> findByVehicleId(Long vehicleId);
}