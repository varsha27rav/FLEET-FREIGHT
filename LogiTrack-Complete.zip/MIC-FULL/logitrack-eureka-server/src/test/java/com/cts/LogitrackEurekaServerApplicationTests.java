package com.cts;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LogitrackEurekaServerApplicationTests {

    @Test
    void contextLoads() {
    }

}
