package com.cts.entity;

import java.time.LocalDateTime;


import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "delivery_records")
@Data
public class DeliveryRecord {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long deliveryId;
    private Long orderId; // FK to Shipment
    private Long vehicleId;
    private Long driverId;
    private LocalDateTime deliveredAt;
    private String status; // SUCCESS, FAILED
}
