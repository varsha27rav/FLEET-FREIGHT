package com.cts.dto;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class DriverRideResponse {
    private Long scheduleId;
    private Long shipmentId;
    private String origin;       // Matches Shipment Entity
    private String destination;  // Matches Shipment Entity
    private String receiverName;
    private String receiverPhone;
    private LocalDateTime departureAt;
    private LocalDateTime arrivalAt;
    private String status;
    private Long vehicleId;
    private Long routeId;
}