package com.cts.client;

import com.cts.dto.ShipmentDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

@FeignClient(name = "logitrack-shipment-service",fallback = ShipmentClientFallback.class)
public interface ShipmentClient {

    @GetMapping("/api/shipments/{id}")
    ShipmentDTO getShipmentById(@PathVariable Long id);

    @PutMapping("/api/shipments/{id}/status")
    void updateShipmentStatus(@PathVariable Long id, @RequestBody String status);
}
