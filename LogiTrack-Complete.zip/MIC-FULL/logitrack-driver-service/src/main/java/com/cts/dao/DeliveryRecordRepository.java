package com.cts.dao;

import com.cts.entity.DeliveryRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface DeliveryRecordRepository extends JpaRepository<DeliveryRecord, Long> {
    List<DeliveryRecord> findByOrderId(Long orderId);
    List<DeliveryRecord> findByDriverId(Long driverId);
}