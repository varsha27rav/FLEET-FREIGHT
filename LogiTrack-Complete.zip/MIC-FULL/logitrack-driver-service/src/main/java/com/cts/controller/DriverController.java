package com.cts.controller;

import com.cts.security.AuthUser;
import com.cts.dao.DeliveryRecordRepository;
import com.cts.dto.DeliveryCompletionRequest;
import com.cts.dto.DriverRideResponse;
import com.cts.entity.DeliveryRecord;
import com.cts.service.DriverService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/driver")
public class DriverController {

    private final DriverService driverService;
    private final DeliveryRecordRepository deliveryRecordRepository;

    public DriverController(DriverService driverService,
                            DeliveryRecordRepository deliveryRecordRepository) {
        this.driverService = driverService;
        this.deliveryRecordRepository = deliveryRecordRepository;
    }

    @PostMapping("/shipments/{id}/complete")
    @PreAuthorize("hasRole('DRIVER')")
    public ResponseEntity<?> completeDelivery(
            @PathVariable Long id,
            @Valid @RequestBody DeliveryCompletionRequest request,
            Authentication auth) {
        AuthUser driver = (AuthUser) auth.getPrincipal();
        String result = driverService.verifyAndCompleteDelivery(
                id, request, driver.getUserId());
        return ResponseEntity.ok(Map.of("message", result));
    }

    @GetMapping("/records/{orderId}")
    @PreAuthorize("hasAnyRole('ADMIN', 'DISPATCHER', 'DRIVER')")
    public ResponseEntity<List<DeliveryRecord>> getDeliveryRecords(
            @PathVariable Long orderId) {
        return ResponseEntity.ok(
                deliveryRecordRepository.findByOrderId(orderId));
    }

    @GetMapping("/my-rides")
    @PreAuthorize("hasRole('DRIVER')")
    public ResponseEntity<List<DriverRideResponse>> getMyScheduledRides(
            Authentication auth) {
        AuthUser driver = (AuthUser) auth.getPrincipal();
        return ResponseEntity.ok(
                driverService.getDriverSchedules(driver.getUserId()));
    }

    @PatchMapping("/trips/{scheduleId}/start")
    @PreAuthorize("hasRole('DRIVER')")
    public ResponseEntity<?> startTrip(
            @PathVariable Long scheduleId,
            Authentication auth) {
        AuthUser driver = (AuthUser) auth.getPrincipal();
        String message = driverService.startTrip(scheduleId, driver.getUserId());
        return ResponseEntity.ok(Map.of("message", message));
    }
}
